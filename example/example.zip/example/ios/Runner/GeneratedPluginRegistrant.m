//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <media_player/MediaPlayerPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [MediaPlayerPlugin registerWithRegistrar:[registry registrarForPlugin:@"MediaPlayerPlugin"]];
}

@end
